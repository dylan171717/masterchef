name 'sonar'

depends "mysql"
depends "nginx"
