name 'graphite'

depends "apache2"
depends "base"
depends "collectd"
depends "cron"
depends "nodejs"
