name 'redmine'

depends "mysql"
depends "rails"
