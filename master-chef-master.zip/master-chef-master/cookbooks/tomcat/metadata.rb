name 'tomcat'

depends "java"
