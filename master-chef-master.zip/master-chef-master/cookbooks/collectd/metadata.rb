name 'collectd'

depends "haproxy"

