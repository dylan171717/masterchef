default[:java][:default_version] = "sun_java6"
default[:java][:versions] = {
  "sun_java6" => "jdk1.6.0_35",
  "oracle_java7" => "jdk1.7.0_07",
  "8_ppa" => "java-8-oracle"
}