
default[:libzmq][:jzmq][:directory] = "/opt/jzmq"
default[:libzmq][:jzmq][:version] = "6f28d8c0eb848580199b6c261ebf0cbe0e208161"
default[:libzmq][:jzmq][:warp_file] = "jzmq_#{default[:libzmq][:jzmq][:version]}_`lsb_release -cs`_`arch`.warp"

default[:libzmq][:package_name] = "libzmq1"