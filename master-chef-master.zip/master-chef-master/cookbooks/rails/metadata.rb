name 'rails'

depends "capistrano"
depends "mysql"
depends "ruby"
depends "supervisor"
depends "unicorn"
