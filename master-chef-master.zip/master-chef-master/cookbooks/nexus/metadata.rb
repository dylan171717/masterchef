name 'nexus'

depends "nginx"
depends "tomcat"
