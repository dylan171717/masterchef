name 'php5'

depends "apache2"
