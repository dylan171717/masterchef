name 'jenkins'

depends "nginx"
depends "tomcat"
