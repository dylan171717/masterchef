default[:exim4] = {
  :interfaces => ['127.0.0.1'],
  :relay_nets => [],
}