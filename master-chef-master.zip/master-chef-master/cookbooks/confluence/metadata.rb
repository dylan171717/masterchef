name 'confluence'

depends "mysql"
depends "nginx"
depends "tomcat"
