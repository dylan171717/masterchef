name 'munin'

depends "cron"
