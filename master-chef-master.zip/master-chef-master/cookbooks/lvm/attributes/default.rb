
default[:lvm][:physical_volumes] = {}
default[:lvm][:volume_groups] = {}
default[:lvm][:logical_volumes] = {}
default[:lvm][:mount_existing_path] = {}
default[:lvm][:mount_new_path] = {}
