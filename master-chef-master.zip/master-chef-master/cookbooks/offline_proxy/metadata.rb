name 'offline_proxy'

depends "nodejs"
