
default[:offline_proxy][:app_directory] = "/apps/offline_proxy"
default[:offline_proxy][:opts] = ""
default[:offline_proxy][:user] = "deploy"
default[:offline_proxy][:repo] = "https://github.com/bpaquet/offline-proxy.git"

