
include_recipe "gitlab::gitlab-shell"

include_recipe "gitlab::gitlab"