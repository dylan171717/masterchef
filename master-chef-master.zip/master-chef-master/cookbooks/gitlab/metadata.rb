name 'gitlab'

depends "git"
depends "mysql"
depends "rails"
depends "redis"
