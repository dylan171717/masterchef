name 'vmware_tools'

