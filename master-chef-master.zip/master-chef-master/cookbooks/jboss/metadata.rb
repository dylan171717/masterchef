name 'jboss'

depends "java"
depends "nginx"
