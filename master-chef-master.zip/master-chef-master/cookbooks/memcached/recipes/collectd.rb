collectd_plugin "memcached" do
  config "Host \"127.0.0.1\"\n  Port \"11211\""
end
