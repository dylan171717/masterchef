name 'nodejs'

depends "capistrano"
depends "logrotate"
