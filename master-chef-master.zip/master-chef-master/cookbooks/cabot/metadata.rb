name 'cabot'

depends "base"
depends "nginx"
depends "postgresql"
depends "redis"
depends "supervisor"
