name 'supervisor'

depends "logrotate"
depends "sudo"
