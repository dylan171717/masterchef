name 'kibana'

depends "nginx"
depends "capistrano"
