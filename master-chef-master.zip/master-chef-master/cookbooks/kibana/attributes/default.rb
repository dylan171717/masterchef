
default[:kibana3] = {
  :url => 'http://download.elasticsearch.org/kibana/kibana/kibana-',
  :version => '3.1.0',
  :directory => '/opt/kibana3',
  :location => '/kibana3',
}

default[:kibana4] = {
	:url => 'https://download.elasticsearch.org/kibana/kibana/kibana-',
  :version => '4.1.2-linux-x64',
  :directory => '/opt/kibana4',
  :location => '/kibana4',
  :opts => '',
}