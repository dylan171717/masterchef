name 'node_logstash'

depends "libzmq"
depends "nodejs"
