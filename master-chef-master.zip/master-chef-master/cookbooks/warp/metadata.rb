name 'warp'

depends "git"
depends "java"
depends "sudo"
