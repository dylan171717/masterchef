name 'elasticsearch'

depends "java"
