name 'mongodb'

depends "logrotate"
