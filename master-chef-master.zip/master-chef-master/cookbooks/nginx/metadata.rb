name 'nginx'

depends "base"

