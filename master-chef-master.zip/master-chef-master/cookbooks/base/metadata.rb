name 'base'

depends "git"
depends "ruby"
depends "warp"
