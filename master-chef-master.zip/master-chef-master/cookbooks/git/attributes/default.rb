default[:git] = {
  :auto_use_http_for_github => true
}