name 'unicorn'

depends "capistrano"
depends "nginx"
